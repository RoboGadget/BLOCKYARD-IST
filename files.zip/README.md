# Blockyard

A tiny, no-build visual layout tool. Drag blocks onto a page, mark each one as a **div**, **photo**, **banner**, or **text** block, then export clean HTML + CSS to paste into any site.

No frameworks, no build step, no dependencies — just `index.html`, one CSS file, and one JS file.

## Try it

Open `index.html` in a browser, or host it for free with **GitHub Pages**:

1. Push this repo to GitHub.
2. Go to **Settings → Pages**.
3. Under "Build and deployment", set source to the `main` branch, root folder.
4. Your tool will be live at `https://<your-username>.github.io/<repo-name>/`.

## How to use it

1. Click **Div**, **Photo**, **Banner**, **Text**, or **Container** in the left sidebar to drop a new block onto the page.
2. Drag a block by its dark label bar to move it. Drop it onto a **Container** to nest it inside — it'll move and resize within that container's edges from then on.
3. Drag the small corner handle to resize a block.
4. Click a block to select it — the right sidebar lets you rename it, set exact X/Y/width/height, add padding and margin, and (for div, banner, text, and container blocks) pick a background color.
5. Double-click into a banner or text block to edit its placeholder wording directly.
6. Click **HTML/CSS ME** in the top bar to get a single, plain HTML + CSS snippet — no JavaScript — that you can paste straight into any page.

The "Page width" dropdown in the top bar changes the width used in the exported layout (desktop/tablet/mobile), so you can rough out a layout at a specific breakpoint.

## Containers

A **Container** block is a drop zone for other blocks. Drag any block's label bar onto one and it becomes a child, positioned and clamped relative to that container instead of the page — so it moves and resizes only within the container's edges. Containers can hold any block type, including other containers. Deleting a container deletes whatever is nested inside it.

## Colors and the `:root` system

Whenever you set a block's background color, it isn't just written inline — it's added to a shared `:root { --block-id-bg: #hex; }` block at the top of the exported stylesheet, and the block's own CSS rule references it with `var(--block-id-bg)`. That keeps your palette in one place, so you can tweak a color once in the `:root` block after pasting and see it apply everywhere that variable is used.

## What gets exported

Each block becomes a `<div class="your-block-name">` positioned absolutely inside a `.page-container` wrapper, so the layout you see on screen is the layout you get:

- **Div** → an empty div with a `<!-- your content here -->` placeholder comment
- **Photo** → an `<img src="your-image.jpg">` filled to the block's size — swap in a real image path
- **Banner** → an `<h2>` with whatever headline text you typed
- **Text** → a `<p>` with whatever body text you typed
- **Container** → a div holding the nested blocks' markup inside it

Any padding or margin you set on a block is carried over as literal `padding`/`margin` CSS. The whole export is plain HTML and CSS with no `<script>` tags — safe to paste into any page without pulling in extra behavior.

Because everything is absolutely positioned, the exported snippet reproduces the sketch exactly, but it isn't responsive on its own — treat it as a fast way to rough out a layout and get real markup to refine, not a finished responsive page.

## Extending it

Everything lives in three files:

- `index.html` — page structure and the two sidebars
- `css/style.css` — all visual styling, including the per-block-type colors
- `js/app.js` — adding/dragging/resizing/selecting blocks and generating the export

To add a new block type (say, a "button" block), search `js/app.js` for the existing `photo`/`banner`/`text` cases — you'll need to add a default size, placeholder content, and an export template, then add a matching `.block-yourtype` style in `css/style.css` and a button in `index.html`.
